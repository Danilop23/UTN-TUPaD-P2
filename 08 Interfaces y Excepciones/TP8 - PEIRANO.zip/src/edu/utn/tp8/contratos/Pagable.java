package edu.utn.tp8.contratos;

public interface Pagable {
    double calcularTotal();
}
