package edu.utn.tp8.contratos;

public interface Notificable {
    void notificar(String mensaje);
}
