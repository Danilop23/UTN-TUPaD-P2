package edu.utn.tp8.excepciones;

public class EdadInvalidaException extends Exception {
    public EdadInvalidaException(String message) {
        super(message);
    }
}
