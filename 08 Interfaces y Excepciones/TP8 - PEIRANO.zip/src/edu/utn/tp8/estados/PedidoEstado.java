package edu.utn.tp8.estados;

public enum PedidoEstado {
    NUEVO, PROCESANDO, PAGADO, ENVIADO, ENTREGADO, CANCELADO
}
