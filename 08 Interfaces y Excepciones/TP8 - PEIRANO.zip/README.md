# TP 8 – Interfaces y Excepciones en Java

Este TP implementa:
- **Interfaces**: `Pagable`, `Pago`, `PagoConDescuento`, `Notificable`.
- **Modelo E-commerce**: `Producto`, `Pedido`, `Cliente`, medios de pago (`TarjetaCredito`, `PayPal`).
- **Notificaciones**: `Pedido` notifica a `Cliente` al cambiar de estado.
- **Excepciones**: 5 ejercicios (división segura, parseo de enteros, lectura de archivo, excepción personalizada `EdadInvalidaException`, y `try-with-resources`).

## Cómo compilar y ejecutar (sin IDE)

Desde la raíz del repo:

```bash
# 1) Compilar
javac -d out $(find src -name "*.java")

# 2) Ejecutar demo de Interfaces (e-commerce)
java -cp out edu.utn.tp8.Main

# 3) Ejecutar ejercicios de Excepciones
java -cp out edu.utn.tp8.excepciones.EjerciciosExcepciones
```

> Sugerencia: también podés abrir la carpeta en IntelliJ / Eclipse, marcar `src/` como *Source Root* y ejecutar `Main` y `EjerciciosExcepciones`.
